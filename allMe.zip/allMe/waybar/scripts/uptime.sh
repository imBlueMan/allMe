#!/bin/sh

# دریافت آپتایم از سیستم و فرمتدهی
uptime=$(uptime -p | sed -e 's/up //g' -e 's/ days/d/g' -e 's/ day/d/g' -e 's/ hours/h/g' -e 's/ hour/h/g' -e 's/ minutes/m/g')
echo "$uptime"
