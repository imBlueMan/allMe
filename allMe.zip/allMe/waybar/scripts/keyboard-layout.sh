#!/bin/sh

# دریافت وضعیت زبان (مثال برای X11)
layout=$(xkblayout-state print "%s")

# نمایش به زبان فارسی یا دلخواه
case "$layout" in
    "us") echo "🇺🇸 EN" ;;
    "ir") echo "🇮🇷 FA" ;;
    *) echo "$layout" ;;
esac
