# add your extensions to the sway configuration here

# when updating definitions files, make sure you include /etc/sway/autostart afterwards, so the definitions for those are updated based on your configuration
