for_window [window_role="PictureInPicture"] \
    floating enable, \
    move container to mark shell, \
    move down, \
    focus, \
    border normal
