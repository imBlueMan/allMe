swayidle \
	timeout 600 '~/.config/sway/lock.sh --grace 10 --fade-in 4' \
  timeout 600 'swaymsg "output \* power off"' resume 'swaymsg "output \* power on"' \
	before-sleep '~/.config/sway/lock.sh'
	"$@"

  # timeout 1200 `systemctl suspend`
	# timeout 800 'swaymsg "output * dpms off"' \
	# resume 'swaymsg "output * dpms on"' \
